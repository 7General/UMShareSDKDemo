# UMShareSDKDemo
友盟分享到qq，微信，邮件和qq登陆、微信登陆功能
